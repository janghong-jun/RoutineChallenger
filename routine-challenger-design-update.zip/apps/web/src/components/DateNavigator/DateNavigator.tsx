'use client';

import React from 'react';
import { useAppDispatch, useAppSelector, goToPreviousDay, goToNextDay, goToToday } from '@routine-challenger/store';
import { HolidayBadge, Icon } from '@routine-challenger/ui';
import styles from './DateNavigator.module.scss';

export const DateNavigator: React.FC = () => {
  const dispatch = useAppDispatch();
  const { selectedDate, todayDate, isHoliday, holidayName } = useAppSelector(state => state.date);

  const formatKoreanDate = (dateString: string) => {
    const [year, month, day] = dateString.split('-').map(Number);
    if (!year || !month || !day) return { main: dateString, sub: '' };
    const dateObj = new Date(year, month - 1, day);
    const dayNames = ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일'];
    const dayName = dayNames[dateObj.getDay()];
    return { main: `${month}월 ${day}일`, sub: `${year}년 ${dayName}` };
  };

  const isToday = selectedDate === todayDate;
  const dateLabel = formatKoreanDate(selectedDate);

  return (
    <div className={styles.container}>
      <div className={styles.dateGroup}>
        <h1 className={styles.dateText} suppressHydrationWarning>
          <span className={styles.dateMain}>{dateLabel.main}</span>
          <span className={styles.dateSub}>{dateLabel.sub}</span>
        </h1>

        <div className={styles.controls}>
          <button
            type="button"
            className={styles.navButton}
            onClick={() => dispatch(goToPreviousDay())}
            aria-label="이전 날짜로 이동"
          >
            <Icon name="chevron-left" size={18} />
          </button>
          <button
            type="button"
            className={styles.navButton}
            onClick={() => dispatch(goToNextDay())}
            aria-label="다음 날짜로 이동"
          >
            <Icon name="chevron-right" size={18} />
          </button>

          {!isToday && (
            <button
              type="button"
              className={styles.todayButton}
              onClick={() => dispatch(goToToday())}
              aria-label="오늘로 돌아가기"
            >
              오늘
            </button>
          )}
        </div>
      </div>

      <div className={styles.statusWrapper}>
        <HolidayBadge isHoliday={isHoliday} holidayName={holidayName} />
      </div>
    </div>
  );
};
